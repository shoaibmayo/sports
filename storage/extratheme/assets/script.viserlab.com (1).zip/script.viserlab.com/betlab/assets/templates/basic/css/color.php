
:root{
    --main: 230            89%
            65%;
}
